package EMed;

import java.awt.BorderLayout;
import java.awt.Choice;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;
import java.util.StringTokenizer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class login_user{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton insertButton,deleteButton,updateButton,viewButton;
	private JPanel p1,p2,p3,p;
	private JLabel lbluser_id,lbllogin_id,lblday;
	private JTextField txtday,txtlogin_id,txtuser_id;
	private Choice user_id,login_id;
	
	private List loginIDList;
	Connection con;ResultSet rs;
	Statement statement;
	private JFrame frame;
	private JMenuItem insert,delete,update,view;
	public login_user(JPanel p,JFrame frame,JMenuItem insert,JMenuItem delete,JMenuItem update,JMenuItem view) 
	{
		
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		
		this.frame=frame;
		this.insert=insert;
		this.delete=delete;
		this.update=update;
		this.view=view;
		
		lbluser_id=new JLabel("User ID");
		lbllogin_id=new JLabel("Login ID");
		lblday=new JLabel("Date");
		
		
		user_id=new Choice();
		login_id=new Choice();
		txtday=new JTextField(8);
		txtlogin_id=new JTextField(8);
		txtuser_id=new JTextField(8);
		
		this.p=p;
		
		
		
	}

	public void connectToDB() 
    {
		try {
		  
		
		Connection con=DriverManager.getConnection(  
		"jdbc:oracle:thin:@localhost:1521:xe","project","project");  
		  
		 
		statement=con.createStatement(); 
		statement.executeUpdate("commit");
		
		
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(p,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
		
		
	}
	public void loadLoginIDs() {
		try {
			loginIDList.removeAll();
			rs=statement.executeQuery("select * from login_user");
			while(rs.next()) {
				loginIDList.add(rs.getString("Login_ID")+"->"+rs.getString("User_ID"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
	}
	
	public void loadlogins() {
	try {
		login_id.removeAll();
		rs=statement.executeQuery("select * from login");
		while(rs.next()) {
			login_id.add(rs.getString("Login_ID"));
		}
		}
	catch(SQLException e) {
		displaySQLErrors(e);
	}
	}
	
	public void loadusers() {
		try {
			user_id.removeAll();
			rs=statement.executeQuery("select * from user_account");
			while(rs.next()) {
				user_id.add(rs.getString("User_ID"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
		}


	public void buildGUI() {
		
		
		
		insert.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				insertButton=new JButton("insert");
				loadlogins();
				loadusers();
				txtday.setText(null);
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(3,1));
				 
				 p1.add(lbllogin_id);
				 p1.add(login_id);
				 p1.add(lbluser_id);
				 p1.add(user_id);
				
				 p1.add(lblday);
				 p1.add(txtday);
				/* p1.add(insertButton);
				
					p1.setBackground(Color.orange) ;
				 p1.setBounds(100,100,300,400);
				*/
				 p3=new JPanel(new FlowLayout());
				 p3.add(insertButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.yellow);
				p3.setBounds(200,280,75,35);
				 p1.setBackground(Color.pink) ;
				 
				 p1.setBounds(115,80,300,200);
				 p2 = new JPanel(new FlowLayout());
					
					 loginIDList=new List(10);
					 loadLoginIDs();
					 p2.add(loginIDList);
					 p2.setBackground(Color.cyan);
					 p2.setBounds(125,320,300,180);  
				 
				 p. add(p1);
				 p.add(p3);
				 p. add(p2);
				 
				
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
					
				 insertButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					String query="INSERT INTO login_user VALUES("+login_id.getSelectedItem()+","+user_id.getSelectedItem()+",'"+txtday.getText()+"')";
					
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\ninserted "+i+" rows succesfully");
					
					loadLoginIDs() ;
					
				}
				catch(SQLException insertException){
					displaySQLErrors(insertException);
				}
				
				 }
			
			
				 	});
			}
			});
		
		

		delete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				deleteButton=new JButton("delete");
				//deleteButton.setSize(1,1);
				txtuser_id.setText(null);
				txtlogin_id.setText(null);
				txtday.setText(null);
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(3,1));
				 
				 p1.add(lbllogin_id);
				 p1.add(txtlogin_id);
				 p1.add(lbluser_id);
				 p1.add(txtuser_id);
				
				 p1.add(lblday);
				 p1.add(txtday);
				 p3=new JPanel(new FlowLayout());
				 p3.add(deleteButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.yellow);
				p3.setBounds(200,280,75,35);
				 p1.setBackground(Color.pink) ;
				 
				 p1.setBounds(115,80,300,200);
				 p2 = new JPanel(new FlowLayout());
					
					 loginIDList=new List(10);
					 loadLoginIDs();
					 p2.add(loginIDList);
					 p2.setBackground(Color.cyan);
					 p2.setBounds(125,320,300,180);  
				 
				 p. add(p1);
				 p.add(p3);
				 p. add(p2);
				 
				 loginIDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from login_user");
								StringTokenizer st=new StringTokenizer(loginIDList.getSelectedItem(),"->");
								String p=st.nextToken();
								String q=st.nextToken();
								
								while (rs.next()) 
								{
									if (rs.getString("login_id").equals(p) && rs.getString("user_id").equals(q))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtlogin_id.setText(rs.getString("login_id"));
									txtuser_id.setText(rs.getString("user_id"));
									txtday.setText(rs.getString("day"));
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});			
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				 deleteButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					
					int a=JOptionPane.showConfirmDialog(p,"Are you sure want to delete:");
					if(a==JOptionPane.YES_OPTION){  
						StringTokenizer st=new StringTokenizer(loginIDList.getSelectedItem(),"->");
				
					String query="DELETE FROM LOGIN_USER WHERE login_ID="+st.nextToken()+" AND USER_ID="+st.nextToken();
				
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nDeleted "+i+" rows succesfully");loadLoginIDs();
					}
					
					
				}
				catch(SQLException deleteException){
					displaySQLErrors(deleteException);
				}
				
				 }
			
			
				 	});
			}
			});
		
		update.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				JButton updateButton = new JButton("update");
				txtuser_id.setText(null);
				txtlogin_id.setText(null);
				txtday.setText(null);
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(3,1));
				 
				 p1.add(lbllogin_id);
				 p1.add(txtlogin_id);
				 p1.add(lbluser_id);
				 p1.add(txtuser_id);
				
				 p1.add(lblday);
				 p1.add(txtday);
				 p3=new JPanel(new FlowLayout());
				 p3.add(updateButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.yellow);
				p3.setBounds(200,280,75,35);
				 p1.setBackground(Color.pink) ;
				 
				 p1.setBounds(115,80,300,200);
				 p2 = new JPanel(new FlowLayout());
					
					 loginIDList=new List(10);
					 loadLoginIDs();
					 p2.add(loginIDList);
					 p2.setBackground(Color.cyan);
					 p2.setBounds(125,320,300,180);  
				 
				 p. add(p1);
				 p.add(p3);
				 p. add(p2);
				 
				 loginIDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from login_user");
								StringTokenizer st=new StringTokenizer(loginIDList.getSelectedItem(),"->");
								String p=st.nextToken();
								String q=st.nextToken();
								
								while (rs.next()) 
								{
									if (rs.getString("login_id").equals(p) && rs.getString("user_id").equals(q))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtlogin_id.setText(rs.getString("login_id"));
									txtuser_id.setText(rs.getString("user_id"));
									txtday.setText(rs.getString("day"));
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});			
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				 updateButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 try {
								
								int a=JOptionPane.showConfirmDialog(p,"Are you sure want to update:");
								if(a==JOptionPane.YES_OPTION){  
									StringTokenizer st=new StringTokenizer(loginIDList.getSelectedItem(),"->");
								String query="update login_user set login_id="+txtlogin_id.getText()+",user_id="+txtuser_id.getText()+",day='"+txtday.getText()+"' WHERE LOGIN_ID="+st.nextToken()+"and USER_ID="+st.nextToken();
								
								int i=statement.executeUpdate(query);
								JOptionPane.showMessageDialog(p,"\nupdated "+i+" rows succesfully");loadLoginIDs() ;
								}
								
								
							}
							catch(SQLException deleteException){
								displaySQLErrors(deleteException);
							}
				
				 }
			
			
				 	});
			}
			});
		
		view.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				Label view1=new Label("Login_user view");
				//view1.setAlignment(Label.CENTER); 
				Font myFont = new Font("Serif",Font.BOLD,50);
				view1.setFont((myFont));
				viewButton=new JButton("View");
				p1=new JPanel();
				p2=new JPanel();
				p1.add(view1);
				p2.add(viewButton);p1.setBackground(Color.cyan) ;p2.setBackground(Color.cyan) ;
				p.add(p1);p.add(p2); p.setLayout(new FlowLayout());
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
				 viewButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 JFrame f; 
						      
						    JTable j; 
						
						        f = new JFrame(); 
						  
						  
						        f.setTitle("login_User details"); 
						        
						       
						        DefaultTableModel model = new DefaultTableModel(); 
						        j = new JTable(model); 
						       model.addColumn("login_id");
						       model.addColumn("User_id");
						       model.addColumn("day");
						      
						       try {
									
									rs=statement.executeQuery("select * from login_user");
									while(rs.next()) {
										 model.addRow(new Object[]{rs.getString("login_id"), rs.getString("user_id"),rs.getString("day")});
									}
									}
								catch(SQLException viewException) {
									displaySQLErrors(viewException);
								}
								j.setEnabled(false);
						        j.setBounds(30, 40, 150, 150); 
						  
						        
						        JScrollPane sp = new JScrollPane(j); 
						        f.add(sp); 
						        
						        f.setSize(400, 400); 
						      
						        f.setVisible(true); 
						       
						        
						    } 
						        
				
				 
			
			
				 	});
				
			        
				
			}
			
		});
		
	}
	
	
	
}
	
	


