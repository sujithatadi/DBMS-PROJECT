package EMed;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


public class EMedUI extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private JMenuBar mnu;
	
	private JMenu mnulogin;
	private JMenu mnulog_user;
	private JMenu mnuuser;
	private JMenu mnumed;
	private JMenu mnuuser_med;
	private JMenu mnuorder_Det;
	private JMenu mnuuser_orderDet;
	
	private JMenuItem insert1,update1,delete1,view1;
	private JMenuItem insert2,update2,delete2,view2;
	private JMenuItem insert3,update3,delete3,view3;
	private JMenuItem insert4,update4,delete4,view4;
	private JMenuItem insert5,update5,delete5,view5;
	private JMenuItem insert6,update6,delete6,view6;
	private JMenuItem insert7,update7,delete7,view7;
	
	private JLabel labelName;

	
	private static JPanel p0,p1;
	
	
	void initialize() {
		mnu=new JMenuBar();
		
		mnulogin= new JMenu("Login");
		mnulog_user= new JMenu("log_user");
		mnuuser= new JMenu("User");
		mnumed= new JMenu("Medicines");
		mnuuser_med= new JMenu("User-Medicine");
		mnuorder_Det= new JMenu("Order_Details");
		mnuuser_orderDet= new JMenu("User_orderDet");
		labelName=new JLabel("E-MEDICINE SALES SYSTEM");
		 p1=new JPanel();
		p0=new JPanel();
		insert1=new JMenuItem("Insert");
		update1=new JMenuItem("Update");
		delete1=new JMenuItem("Delete");
		view1=new JMenuItem("View");
insert2=new JMenuItem("Insert");
		update2=new JMenuItem("Update");
		delete2=new JMenuItem("Delete");
		view2=new JMenuItem("View");
		insert3=new JMenuItem("Insert");
		update3=new JMenuItem("Update");
		delete3=new JMenuItem("Delete");
		view3=new JMenuItem("View");
		insert4=new JMenuItem("Insert");
		update4=new JMenuItem("Update");
		delete4=new JMenuItem("Delete");
		view4=new JMenuItem("View");
		insert5=new JMenuItem("Insert");
		update5=new JMenuItem("Update");
		delete5=new JMenuItem("Delete");
		view5=new JMenuItem("View");
		insert6=new JMenuItem("Insert");
		update6=new JMenuItem("Update");
		delete6=new JMenuItem("Delete");
		view6=new JMenuItem("View");
		insert7=new JMenuItem("Insert");
		update7=new JMenuItem("Update");
		delete7=new JMenuItem("Delete");
		view7=new JMenuItem("View");
		insert1=new JMenuItem("Insert");
		update1=new JMenuItem("Update");
delete1=new JMenuItem("Delete");
		view1=new JMenuItem("View");
	}
	void addComponentsToFrame() {
		 mnulogin.add(insert1);
		 mnulogin.add(delete1);
		 mnulogin.add(update1);
		 mnulogin.add(view1);
		  mnulog_user.add(insert2);
		 mnulog_user.add(delete2);
		 mnulog_user.add(update2);
		 mnulog_user.add(view2);
		 mnuuser.add(insert3);
		 mnuuser.add(delete3);
		 mnuuser.add(update3);
		 mnuuser.add(view3);
		  mnumed.add(insert4);
		 mnumed.add(delete4);
		 mnumed.add(update4);
		 mnumed.add(view4);
		  mnuuser_med.add(insert5);
		 mnuuser_med.add(delete5);
		 mnuuser_med.add(update5);
		 mnuuser_med.add(view5);
		  mnuorder_Det.add(insert6);
		 mnuorder_Det.add(delete6);
		 mnuorder_Det.add(update6);
		 mnuorder_Det.add(view6);
		  mnuuser_orderDet.add(insert7);
		 mnuuser_orderDet.add(delete7);
		 mnuuser_orderDet.add(update7);
		 mnuuser_orderDet.add(view7);
		 mnu.add(mnulogin);
		 mnu.add(mnuuser);
		 mnu.add(mnulog_user);
		 mnu.add(mnumed);
		 mnu.add(mnuuser_med);
		 mnu.add(mnuorder_Det);
		 mnu.add(mnuuser_orderDet);
		 setJMenuBar(mnu); 
		 p1.add(labelName);p1.setAlignmentY(CENTER_ALIGNMENT); 
		 p1.setBounds(500,500,800,100);	
		p0.add(p1);
		 p0.setBackground(Color.CYAN);
		 add(p0);
	}
void closeWindow(){
		try {
			int a=JOptionPane.showConfirmDialog(this,"Are you sure want to Quit EMedicine Sales System:");
			if(a==JOptionPane.YES_OPTION){  
				JOptionPane.showMessageDialog(this,
					    "Thank you!\nExiting EMedicine Sales System","Quit",
					    JOptionPane.WARNING_MESSAGE);
				System.exit(0);
			}
			else if (a== JOptionPane.NO_OPTION) {
				setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
			}
			else if (a== JOptionPane.CANCEL_OPTION) {
				setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
			}
		}
			catch(Exception e) {
				System.out.println(e);
				}
	}
	void register() {
login log=new login(p0,EMedUI.this,insert1,delete1,update1,view1);
		log.buildGUI();
		User_account user=new User_account(p0,EMedUI.this,insert3,delete3,update3,view3); 
		user.buildGUI();
		login_user log_user=new login_user(p0,EMedUI.this,insert2,delete2,update2,view2); 
		log_user.buildGUI();
		Medicine med=new Medicine(p0,EMedUI.this,insert4,delete4,update4,view4); 
		med.buildGUI();
		UserMedicine umed=new UserMedicine(p0,EMedUI.this,insert5,delete5,update5,view5); 
		umed.buildGUI();
		orderDetails orders=new orderDetails(p0,EMedUI.this,insert6,delete6,update6,view6); 
		orders.buildGUI();
		UserOrderDetails u_orders=new UserOrderDetails(p0,EMedUI.this,insert7,delete7,update7,view7); 
		u_orders.buildGUI();
		addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent we) 
			{ 
				closeWindow();
			} 
		}); 
		
}
public EMedUI() {
		initialize();
		addComponentsToFrame();
		register();
		pack();
	//	setBackground(Color.RED);
		setTitle("E-Medicine Sales System");
		setSize(800,800);
		setVisible(true);
	}
}
