package EMed;

import java.awt.BorderLayout;
import java.awt.Choice;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;
import java.util.StringTokenizer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class UserMedicine{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton insertButton,deleteButton,updateButton,viewButton;
	private JPanel p1,p2,p3,p;
	private JLabel lbluser_id,lblmid,lblquantity,lblday;
	private JTextField txtuser_id,txtmid,txtquantity,txtday;
	private Choice user_id,mid;
	private List UserMIDList;
	Connection con;ResultSet rs;
	Statement statement;
	private JFrame frame;
	private JMenuItem insert,delete,update,view;
	public UserMedicine(JPanel p,JFrame frame,JMenuItem insert,JMenuItem delete,JMenuItem update,JMenuItem view) 
	{
		
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		
		this.frame=frame;
		this.insert=insert;
		this.delete=delete;
		this.update=update;
		this.view=view;
		
		lbluser_id=new JLabel("User ID");
		lblmid=new JLabel("Medicine ID");
		lblquantity=new JLabel("Quantity");
		lblday=new JLabel("Date");
		
		user_id=new Choice();
		mid=new Choice();
		
		txtuser_id=new JTextField(15);
		txtmid=new JTextField(15);
		txtquantity=new JTextField(8);
		txtday=new JTextField(8);
		
		this.p=p;
		
		
		
	}

	public void connectToDB() 
    {
		try {
		  
		
		Connection con=DriverManager.getConnection(  
		"jdbc:oracle:thin:@localhost:1521:xe","project","project");  
		  
		 
		statement=con.createStatement(); 
		statement.executeUpdate("commit");
		
		
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(p,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
		
		
	}
	public void loaduserIDs() {
		try {
			UserMIDList.removeAll();
			rs=statement.executeQuery("select * from user_medicine");
			while(rs.next()) {
				UserMIDList.add(rs.getString("USER_ID")+"->"+rs.getString("MID"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
	}
	public void loadusers() {
		try {
			user_id.removeAll();
			rs=statement.executeQuery("select * from user_account");
			while(rs.next()) {
				user_id.add(rs.getString("User_ID"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
		}
	public void loadmids() {
		try {
			mid.removeAll();
			rs=statement.executeQuery("select * from medicine");
			while(rs.next()) {
				mid.add(rs.getString("MID"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
		}

	public void buildGUI() {
		
		
		
		insert.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				insertButton=new JButton("insert");
				txtuser_id.setText(null);
				txtmid.setText(null);
				txtquantity.setText(null);
				txtday.setText(null);
				loadusers();
				loadmids();
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(4,1));
				 
				 p1.add(lbluser_id);
				 p1.add(user_id);
				 p1.add(lblmid);
				 p1.add(mid);
				 p1.add(lblquantity);
				 p1.add(txtquantity);
				 p1.add(lblday);
				 p1.add(txtday);
				 p3=new JPanel(new FlowLayout());
				 p3.add(insertButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.yellow);
				p3.setBounds(200,350,75,35);
				 p1.setBackground(Color.pink) ;
				 
				 p1.setBounds(115,80,300,250);
				
				 p2 = new JPanel(new FlowLayout());
					
					 UserMIDList=new List(10);
					 loaduserIDs();
					 p2.add(UserMIDList);
					 p2.setBounds(450,150,350,180);  p2.setBackground(Color.cyan) ;
				 
				 
				 p. add(p1);p.add(p3);
				 p. add(p2);
				 
				UserMIDList.setEnabled(false);
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
					
				 insertButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					String query="INSERT INTO USER_MEDICINE VALUES("+user_id.getSelectedItem()+","+mid.getSelectedItem()+","+txtquantity.getText()+",'"+txtday.getText()+"')";
					
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\ninserted "+i+" rows succesfully");loaduserIDs();
					
					
					
				}
				catch(SQLException insertException){
					displaySQLErrors(insertException);
				}
				
				 }
			
			
				 	});
			}
			});
		
		

		delete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				deleteButton=new JButton("delete");
				//deleteButton.setSize(1,1);
				txtuser_id.setText(null);
				txtmid.setText(null);
				txtquantity.setText(null);
				txtday.setText(null);
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(4,1));
				 
				 p1.add(lbluser_id);
				 p1.add(txtuser_id);
				 p1.add(lblmid);
				 p1.add(txtmid);
				 p1.add(lblquantity);
				 p1.add(txtquantity);
				 p1.add(lblday);
				 p1.add(txtday);
				
				 p3=new JPanel(new FlowLayout());
				 p3.add(deleteButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.yellow);
				p3.setBounds(200,350,75,35);
				 p1.setBackground(Color.pink) ;
				 
				 p1.setBounds(115,80,300,250);
				
				 p2 = new JPanel(new FlowLayout());
					
					 UserMIDList=new List(10);
					 loaduserIDs();
					 p2.add(UserMIDList);
					 p2.setBounds(450,150,350,180);  p2.setBackground(Color.cyan) ;
				 
				 
				 p. add(p1);p.add(p3);
				 p. add(p2);
				 
				 UserMIDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from user_medicine");
								StringTokenizer st=new StringTokenizer(UserMIDList.getSelectedItem(),"->");
								String p=st.nextToken();
								String q=st.nextToken();
								
								while (rs.next()) 
								{
									if (rs.getString("user_id").equals(p) && rs.getString("mid").equals(q))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtmid.setText(rs.getString("mid"));
									txtuser_id.setText(rs.getString("user_id"));
									txtquantity.setText(rs.getString("quantity"));
									txtday.setText(rs.getString("day"));
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});			
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				 deleteButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					
					int a=JOptionPane.showConfirmDialog(p,"Are you sure want to delete:");
					if(a==JOptionPane.YES_OPTION){  
						StringTokenizer st=new StringTokenizer(UserMIDList.getSelectedItem(),"->");
				
					String query="DELETE FROM USER_MEDICINE WHERE USER_ID="+st.nextToken();
				
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nDeleted "+i+" rows succesfully");loaduserIDs();
					}
					
					
				}
				catch(SQLException deleteException){
					displaySQLErrors(deleteException);
				}
				
				 }
			
			
				 	});
			}
			});
		
		update.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				JButton updateButton = new JButton("update");
				txtuser_id.setText(null);
				txtmid.setText(null);
				txtquantity.setText(null);
				txtday.setText(null);
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(4,1));
				 
				 p1.add(lbluser_id);
				 p1.add(txtuser_id);
				 p1.add(lblmid);
				 p1.add(txtmid);
				 p1.add(lblquantity);
				 p1.add(txtquantity);
				 p1.add(lblday);
				 p1.add(txtday);
				 p3=new JPanel(new FlowLayout());
				 p3.add(updateButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.yellow);
				p3.setBounds(200,350,75,35);
				 p1.setBackground(Color.pink) ;
				 
				 p1.setBounds(115,80,300,250);
				
				 p2 = new JPanel(new FlowLayout());
					
					 UserMIDList=new List(10);
					 loaduserIDs();
					 p2.add(UserMIDList);
					 p2.setBounds(450,150,350,180);  p2.setBackground(Color.cyan) ;
				 
				 
				 p. add(p1);p.add(p3);
				 p. add(p2);
				 
				 UserMIDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from user_medicine");
								StringTokenizer st=new StringTokenizer(UserMIDList.getSelectedItem(),"->");
								String p=st.nextToken();
								String q=st.nextToken();
								
								while (rs.next()) 
								{
									if (rs.getString("user_id").equals(p) && rs.getString("mid").equals(q))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtmid.setText(rs.getString("mid"));
									txtuser_id.setText(rs.getString("user_id"));
									txtquantity.setText(rs.getString("quantity"));
									txtday.setText(rs.getString("day"));
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});		
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				
				 updateButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 try {
								
								int a=JOptionPane.showConfirmDialog(p,"Are you sure want to update:");
								if(a==JOptionPane.YES_OPTION){  
									StringTokenizer st=new StringTokenizer(UserMIDList.getSelectedItem(),"->");
								String query="update user_medicine set mid="+txtmid.getText()+",quantity="+txtquantity.getText()+",day='"+txtday.getText()+"' WHERE USER_ID="+st.nextToken()+"and mid="+st.nextToken();
								
								int i=statement.executeUpdate(query);
								JOptionPane.showMessageDialog(p,"\nupdated "+i+" rows succesfully");loaduserIDs();
								}
								
								
							}
							catch(SQLException deleteException){
								displaySQLErrors(deleteException);
							}
				
				 }
			
			
				 	});
			}
			});
		
		view.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				Label view1=new Label("User_Medicines view");
				//view1.setAlignment(Label.CENTER); 
				Font myFont = new Font("Serif",Font.BOLD,50);
				view1.setFont((myFont));
				viewButton=new JButton("View");
				p1=new JPanel();
				p2=new JPanel();
				p1.add(view1);
				p2.add(viewButton);p1.setBackground(Color.cyan) ;p2.setBackground(Color.cyan) ;
				p.add(p1);p.add(p2);
				 p.setLayout(new FlowLayout());
				
					
				p.setBounds(500,800,300,300);
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
				 viewButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 JFrame f; 
						    
						    JTable j; 
						
						        f = new JFrame(); 
						  
						  
						        f.setTitle("User_Medicine Details "); 
						        
						       
						        DefaultTableModel model = new DefaultTableModel(); 
						        j = new JTable(model); 
						       model.addColumn("User ID");
						       model.addColumn("Medicine ID");
						       model.addColumn("Quantity");
						       model.addColumn("Day");
						      
						       try {
									
									rs=statement.executeQuery("select * from user_medicine");
									while(rs.next()) {
										 model.addRow(new Object[]{rs.getString("user_id"), rs.getString("mid"),rs.getString("quantity"),rs.getString("day")});
									}
									}
								catch(SQLException viewException) {
									displaySQLErrors(viewException);
								}
								j.setEnabled(false);
						        j.setBounds(30, 40, 180, 150); 
						  
						        
						        JScrollPane sp = new JScrollPane(j); 
						        f.add(sp); 
						        
						        f.setSize(500, 400); 
						      
						        f.setVisible(true); 
						       
						        
						    } 
						        
				
				 
			
			
				 	});
				
			        
				
			}
			
		});
		
		
	}
	
	
	
}
	
	


