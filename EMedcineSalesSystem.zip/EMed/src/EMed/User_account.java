package EMed;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class User_account {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton insertButton,deleteButton,updateButton,viewButton;
	private JPanel p1,p2,p3,p;
	private JLabel lbluser_id,lblusername,lblpwd,lblpno,lblemail,lbladd;
	private JTextField txtuser_id,txtusername,txtpwd,txtpno,txtemail;
	private JTextArea txtadd;
	private List userIDList;
	Connection con;ResultSet rs;
	Statement statement;
	private JFrame frame;
	private JMenuItem insert,delete,update,view;
	public User_account(JPanel p,JFrame frame,JMenuItem insert,JMenuItem delete,JMenuItem update,JMenuItem view) 
	{
		
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		
		this.frame=frame;
		this.insert=insert;
		this.delete=delete;
		this.update=update;
		this.view=view;
		
		lbluser_id=new JLabel("user_ID");
		lblusername=new JLabel("UserName");
		lblpwd=new JLabel("Password");
		lblpno=new JLabel("phone Number");
		lblemail=new JLabel("email");
		lbladd=new JLabel("address");
		
		txtuser_id=new JTextField(15);
		txtusername=new JTextField(15);
		txtpwd=new JPasswordField(8);
		txtpno=new JTextField(15);
		txtemail=new JTextField(30);
		txtadd=new JTextArea(15,15);
		
		this.p=p;
		
		
		
	}

	public void connectToDB() 
    {
		try {
		  
		
		Connection con=DriverManager.getConnection(  
		"jdbc:oracle:thin:@localhost:1521:xe","project","project");  
		  
		 
		statement=con.createStatement(); 
		statement.executeUpdate("commit");
		
		
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(p,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
		
		
	}
	public void loaduserIDs() {
		try {
			userIDList.removeAll();
			rs=statement.executeQuery("select user_id from user_account");
			while(rs.next()) {
				userIDList.add(rs.getString("user_ID"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
	}

	public void buildGUI() {
		
		
		
		insert.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				insertButton=new JButton("insert");
				txtuser_id.setText(null);
				txtusername.setText(null);
				txtpwd.setText(null);
				txtpno.setText(null);
				txtemail.setText(null);
				txtadd.setText(null);
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(6,7));
				 p1.add(lbluser_id);
				 p1.add(txtuser_id);
				 p1.add(lblusername);
				 p1.add(txtusername);
				 p1.add(lblpwd);
				 p1.add(txtpwd);
				 p1.add(lblpno);
				 p1.add(txtpno);
				 p1.add(lblemail);
				 p1.add(txtemail);
				 p1.add(lbladd);
				 p1.add(txtadd);
				 p1.setBackground(Color.pink) ;
				 p3=new JPanel(new FlowLayout());
				 p3.add(insertButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.yellow);
				p3.setBounds(200,480,75,35);
					 
				 p1.setBounds(100,100,400,350);
				
				 p2 = new JPanel(new FlowLayout());
				
				 userIDList=new List(10);
				 loaduserIDs();
				 p2.add(userIDList);p2.setBackground(Color.cyan) ;
				 
				 p2.setBounds(500,200,350,180);  
				 
				 
				 p. add(p1);
				 
				 p.add(p3);   
		
				 p. add(p2);
				 
					
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
					
				 insertButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					String query="INSERT INTO user_account VALUES("+txtuser_id.getText()+",'"+txtusername.getText()+"','"+txtpwd.getText()+"',"+txtpno.getText()+",'"+txtemail.getText()+"','"+txtadd.getText()+"')";
					
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\ninserted "+i+" rows succesfully");
					
					loaduserIDs();
					
				}
				catch(SQLException insertException){
					displaySQLErrors(insertException);
				}
				
				 }
			
			
				 	});
			}
			});

		delete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				deleteButton=new JButton("delete");
				
				txtuser_id.setText(null);
				txtusername.setText(null);
				txtpwd.setText(null);
				txtpno.setText(null);
				txtemail.setText(null);
				txtadd.setText(null);
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				p1=new JPanel();
				
				p1.setLayout(new GridLayout(6,7));
				 p1.add(lbluser_id);
				 p1.add(txtuser_id);
				 p1.add(lblusername);
				 p1.add(txtusername);
				 p1.add(lblpwd);
				 p1.add(txtpwd);
				 p1.add(lblpno);
				 p1.add(txtpno);
				 p1.add(lblemail);
				 p1.add(txtemail);
				 p1.add(lbladd);
				 p1.add(txtadd);
				 //p1.add(deleteButton);
				 p1.setBackground(Color.pink) ;
				 p3=new JPanel(new FlowLayout());
				 p3.add(deleteButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.yellow);
					p3.setBounds(200,480,75,35);
					 
					 p1.setBounds(100,100,400,350);
				
				 p2 = new JPanel(new FlowLayout());
				
				 userIDList=new List(10);
				 loaduserIDs();
				 p2.add(userIDList);p2.setBackground(Color.cyan) ;
				 
				 p2.setBounds(500,200,350,180);  
				 
				 
				 p. add(p1);
				 
				 p.add(p3);   
		
				 p. add(p2);
				 userIDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from user_account");
								while (rs.next()) 
								{
									if (rs.getString("user_id").equals(userIDList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtuser_id.setText(rs.getString("user_ID"));
									txtusername.setText(rs.getString("username"));
									txtpwd.setText(rs.getString("password"));
									txtpno.setText(rs.getString("pno"));
									txtemail.setText(rs.getString("email"));
									txtadd.setText(rs.getString("address"));
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});			
				 
				 p.setLayout(new BorderLayout());
				
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
				
				 deleteButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					
					int a=JOptionPane.showConfirmDialog(p,"Are you sure want to delete:");
					if(a==JOptionPane.YES_OPTION){  
					String query="DELETE FROM user_account WHERE user_ID="+userIDList.getSelectedItem();
				
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nDeleted "+i+" rows succesfully");loaduserIDs();
					}
					
					
				}
				catch(SQLException deleteException){
					displaySQLErrors(deleteException);
				}
				
				 }
			
			
				 	});
			}
			});
		
		update.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				JButton updateButton = new JButton("update");
				
				txtuser_id.setText(null);
				txtusername.setText(null);
				txtpwd.setText(null);
				txtpno.setText(null);
				txtemail.setText(null);
				txtadd.setText(null);
				
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				p1=new JPanel();
				
				p1.setLayout(new GridLayout(6,7));
				 p1.add(lbluser_id);
				 p1.add(txtuser_id);
				 p1.add(lblusername);
				 p1.add(txtusername);
				 p1.add(lblpwd);
				 p1.add(txtpwd);
				 p1.add(lblpno);
				 p1.add(txtpno);
				 p1.add(lblemail);
				 p1.add(txtemail);
				 p1.add(lbladd);
				 p1.add(txtadd);
				 p1.setBackground(Color.pink) ;
				 p3=new JPanel(new FlowLayout());
				 p3.add(updateButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.yellow);
					p3.setBounds(200,480,75,35);
					 
					 p1.setBounds(100,100,400,350);
				
				 p2 = new JPanel(new FlowLayout());
				
				 userIDList=new List(10);
				 loaduserIDs();
				 p2.add(userIDList);p2.setBackground(Color.cyan) ;
				 
				 p2.setBounds(500,200,350,180);  
				 
				 
				 p. add(p1);
				 
				 p.add(p3);   
		
				 p. add(p2);
				 userIDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from user_account");
								while (rs.next()) 
								{
									if (rs.getString("user_id").equals(userIDList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtuser_id.setText(rs.getString("user_ID"));
									txtusername.setText(rs.getString("username"));
									txtpwd.setText(rs.getString("password"));
									txtpno.setText(rs.getString("pno"));
									txtemail.setText(rs.getString("email"));
									txtadd.setText(rs.getString("address"));
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});			
				 
				 p.setLayout(new BorderLayout());
				
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
					
				
				 updateButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 try {
								
								int a=JOptionPane.showConfirmDialog(p,"Are you sure want to update:");
								if(a==JOptionPane.YES_OPTION){  
								String query="update user_account set username='"+txtusername.getText()+"',password='"+txtpwd.getText()+"',pno="+txtpno.getText()+",email='"+txtemail.getText()+"',address='"+txtadd.getText()+"' WHERE user_ID="+userIDList.getSelectedItem();
								
								int i=statement.executeUpdate(query);
								JOptionPane.showMessageDialog(p,"\nupdated "+i+" rows succesfully");loaduserIDs();
								}
								
								
							}
							catch(SQLException deleteException){
								displaySQLErrors(deleteException);
							}
				
				 }
			
			
				 	});
			}
			});
		
		view.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				Label view1=new Label("UserAccount view");
				//view1.setAlignment(Label.CENTER); 
				Font myFont = new Font("Serif",Font.BOLD,50);
				view1.setFont((myFont));
				viewButton=new JButton("View");
				p1=new JPanel();
				p2=new JPanel();
				p1.add(view1);
				p2.add(viewButton);p1.setBackground(Color.cyan) ;p2.setBackground(Color.cyan) ;
				p.add(p1);p.add(p2); p.setLayout(new FlowLayout());
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
				 viewButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 JFrame f; 
						      
						    JTable j; 
						
						        f = new JFrame(); 
						  
						  
						        f.setTitle("login_User details"); 
						        
						       
						        DefaultTableModel model = new DefaultTableModel(); 
						        j = new JTable(model); 
						       model.addColumn("User_id");
						       model.addColumn("Username");
						       model.addColumn("Password");
						       model.addColumn("PhoneNumber");
						       model.addColumn("E-Mail");
						       model.addColumn("Address");
						      
						       try {
									
									rs=statement.executeQuery("select * from user_account");
									while(rs.next()) {
										 model.addRow(new Object[]{rs.getString("user_id"), rs.getString("username"),rs.getString("password"),rs.getString("pno"),rs.getString("email"),rs.getString("address"),});
									}
									}
								catch(SQLException viewException) {
									displaySQLErrors(viewException);
								}
								j.setEnabled(false);
						        j.setBounds(30, 40, 300, 300); 
						  
						        
						        JScrollPane sp = new JScrollPane(j); 
						        f.add(sp); 
						        
						        f.setSize(800, 400); 
						      
						        f.setVisible(true); 
						       
						        
						    } 
						        
				
				 
			
			
				 	});
				
			        
				
			}
			
		});
		
	}
	
	
	
}
	
	


